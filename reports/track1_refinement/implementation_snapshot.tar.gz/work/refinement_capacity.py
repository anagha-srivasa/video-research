import numpy as np,json
from collections import defaultdict
from refinement.protocol import config,folder
from refinement.data import temporal_cases
from refinement.build import directory
from pipeline.common import atomic_json
from track1.numerics import basis
from track1.artifacts import load_shard
import pyarrow.parquet as pq
cfg=config();scale=np.asarray(json.loads((directory('calibration')/'model.json').read_text())['feature_scale']);totals=defaultdict(list)
for v in cfg['train']+cfg['validation']+cfg['test']:
 f=load_shard(directory('functional')/f'{v}.pt');lookup={(r['entity_track_id'],r['window_end_us']):r['row_index'] for r in pq.read_table(directory('functional')/f'{v}.parquet').to_pylist()}
 for case in temporal_cases([v]):
  phi=basis(2*case['time']-1);h=case['h'];c=np.linalg.lstsq(phi,h,rcond=None)[0];stored=f['coefficients'][lookup[(case['entity_track_id'],case['window_end_us'])]];floor=float(np.mean(((phi@c-h)/scale)**2));actual=float(np.mean(((phi@stored-h)/scale)**2));totals[case['split']].append((floor,actual))
result={k:dict(windows=len(rs),all_point_cubic_lower_bound_normalised_rmse=float(np.sqrt(np.mean([r[0] for r in rs]))),stored_fit_normalised_rmse=float(np.sqrt(np.mean([r[1] for r in rs]))),stored_to_lower_bound_rmse_ratio=float(np.sqrt(np.sum([r[1] for r in rs])/np.sum([r[0] for r in rs])))) for k,rs in totals.items()}
atomic_json(folder('reports')/'compression_limit.json',dict(splits=result,scope='Equal-observation in-sample compression objective only. Unweighted all-observation cubic least squares sees every target and is the exact fixed-cubic lower bound for this objective. Not a held-out or forecasting oracle. Stored fit trades regularization, variance and coverage weighting against this objective. Aggregate here is pooled case RMSE, not the video-macro held-out score.'))
print(result,flush=True)
