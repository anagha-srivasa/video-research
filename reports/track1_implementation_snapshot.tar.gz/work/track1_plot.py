from pathlib import Path
import json,os
os.environ['MPLCONFIGDIR']=str(Path('work/mplconfig').resolve())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
root=Path.cwd();cal=json.loads((root/'derived/track1_calibration_v1/model.json').read_text());pca=json.loads((root/'derived/track1_appearance_v1/projection.json').read_text());ab=json.loads((root/'reports/track1_ablations.json').read_text())
fig,ax=plt.subplots(2,2,figsize=(13,8),layout='constrained')
labels=['Train','Engineering val','Engineering test','Source VISOR val'];keys=['train','validation','test','source_visor_validation'];x=np.arange(4)
before=[cal['evaluations'][k+'/manual_sparse']['before']['coverage95'] for k in keys];after=[cal['evaluations'][k+'/manual_sparse']['after']['coverage95'] for k in keys]
ax[0,0].bar(x-.18,before,.36,label='Before calibration',color='#adb5bd');ax[0,0].bar(x+.18,after,.36,label='After train-only calibration',color='#247b91');ax[0,0].axhline(.95,ls='--',color='#b64b43',label='Nominal 95%');ax[0,0].set_xticks(x,labels,rotation=10);ax[0,0].set_ylim(.7,1.);ax[0,0].set_ylabel('Held-out vertex coverage');ax[0,0].set_title('Manual contour representation uncertainty');ax[0,0].legend(fontsize=8)
for split,videos in [('Validation',['P08_09','P18_03']),('Test',['P06_108','P21_01'])]:
 dims=[0,8,16,32,64,128];errors=[np.mean([pca['evaluations'][v]['reconstruction_mse_by_components'][str(k)] for v in videos]) for k in dims];ax[0,1].plot(dims,errors,'o-',label=split)
ax[0,1].set_xlabel('Train-only PCA components');ax[0,1].set_ylabel('Frozen feature reconstruction MSE');ax[0,1].set_title('Appearance projection on held-out videos');ax[0,1].legend()
labels=['Degree 2','Degree 3 baseline','Degree 4','Nearest observation'];keys=['degree_2','degree_3','degree_4','nearest'];vals=[ab['temporal']['validation/'+k]['heldout_state_rmse'] for k in keys];ax[1,0].bar(np.arange(4),vals,color=['#adb5bd','#247b91','#adb5bd','#b98445']);ax[1,0].set_xticks(np.arange(4),labels,rotation=12);ax[1,0].set_ylabel('35-D state RMSE');ax[1,0].set_title('Held-out temporal reconstruction')
resources=[json.loads(line) for line in (root/'reports/track1_resources.jsonl').read_text().splitlines()];rss=np.array([r['rss_gib'] for r in resources]);avail=np.array([r['available_gib'] for r in resources]);origin=datetime.fromisoformat(resources[0]['time']);elapsed=np.array([(datetime.fromisoformat(r['time'])-origin).total_seconds()/60 for r in resources]);ax[1,1].plot(elapsed,rss,label='Recorded process-tree RSS');ax[1,1].plot(elapsed,avail,label='System available');global_rows=[json.loads(line) for line in (root/'reports/track1_global_resources.jsonl').read_text().splitlines()];ax[1,1].plot([(datetime.fromisoformat(r['time'])-origin).total_seconds()/60 for r in global_rows],[r['project_python_rss_gib'] for r in global_rows],label='Aggregate RSS during parallel stage',color='#31916c');ax[1,1].axhline(20,ls='--',color='#b64b43',label='Process budget');ax[1,1].axhline(5,ls=':',color='#b64b43',label='System reserve');ax[1,1].set_xlabel('Elapsed minutes (includes gold and restart logs)');ax[1,1].set_ylabel('GiB');ax[1,1].set_title('Observed resource envelope');ax[1,1].legend(fontsize=8)
fig.suptitle('Track 1 pilot diagnostics · fixed blueprint baseline',fontsize=16)
for a in ax.flat:a.spines[['top','right']].set_visible(False);a.grid(axis='y',alpha=.15);a.set_axisbelow(True)
fig.savefig(root/'reports/track1_diagnostics.png',dpi=160);plt.close(fig)
print('Rendered reports/track1_diagnostics.png')
