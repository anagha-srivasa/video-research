from collections import Counter
from pathlib import Path
import json,tarfile,importlib.metadata as md
import numpy as np
import pyarrow.parquet as pq
from pipeline.common import ROOT,atomic_json,digest
from track1.artifacts import load_config,load_shard,reusable,identity
from track1.temporal import evaluate,collocation
from track1.store import Track1Dataset
cfg=load_config();choices=json.loads((ROOT/'dataset/metadata/pilot_selection.json').read_text());per_video=[];excluded=Counter();totals=Counter();numerical=[]
for choice in choices:
 v=choice['video_id'];base=ROOT/'derived';sp=base/'track1_spatial_v1';fn=base/'track1_functional_v1'
 for stage in ['spatial','calibration','appearance','functional']:assert reusable(cfg,stage,v),(stage,v,'stale or corrupt')
 spatial=load_shard(sp/f'{v}.pt');rows=pq.read_table(sp/f'{v}.parquet').to_pylist();bad=pq.read_table(sp/f'{v}.excluded.parquet').to_pylist()
 assert len(rows)+len(bad)==pq.read_metadata(ROOT/f'canonical/v1/masks.{v}.parquet').num_rows
 ids=[r['mask_uid'] for r in rows]+[r['mask_uid'] for r in bad];assert len(ids)==len(set(ids))
 for r in bad:excluded[r['reason']]+=1
 assert len(rows)==len(spatial['h'])
 for key in ['controls','covariance','h','variance','normal_variance']:
  for begin in range(0,len(rows),4096):assert np.isfinite(spatial[key][begin:begin+4096]).all(),(v,key)
 assert (spatial['variance']>=0).all();assert (spatial['normal_variance']>=0).all()
 tensor=load_shard(fn/f'{v}.pt');windows=pq.read_table(fn/f'{v}.parquet').to_pylist();app=load_shard(base/f'track1_appearance_v1/{v}.pt')
 assert len(windows)==len(tensor['coefficients']);assert app['embedding'].shape==(len(rows),128);assert np.isfinite(app['embedding']).all()
 assert all(np.isfinite(tensor[k]).all() for k in tensor)
 assert all(r['video_id']==v and r['engineering_split']==next(s for s,vs in cfg['engineering_splits'].items() if v in vs) and r['action_split']==choice['action_split'] and r['visor_split']==choice['visor_split'] for r in windows)
 valid_ids=np.array([i for i,r in enumerate(windows) if r['valid']]);assert len(valid_ids)>0
 for i in valid_ids[np.linspace(0,len(valid_ids)-1,min(8,len(valid_ids)),dtype=int)]:
  c=tensor['coefficients'][i].astype(float);h,vel,acc=evaluate(c,np.array([1.]))
  assert np.allclose(h[0],tensor['endpoint'][i],atol=5e-5,rtol=1e-4)
  assert np.allclose(vel[0],tensor['endpoint_velocity'][i],atol=5e-4,rtol=1e-4)
  assert np.allclose(acc[0],tensor['endpoint_accel'][i],atol=5e-3,rtol=1e-4)
  nodes=collocation(c);assert np.allclose(nodes['xi'],tensor['xi'][i],atol=5e-4,rtol=1e-4)
  assert np.linalg.eigvalsh(tensor['coefficient_cov'][i]).min()>-1e-5
  numerical.append(dict(video_id=v,row_index=int(i),passed=True))
 review=json.loads((ROOT/f'reports/track1_visual_review.{v}.json').read_text());eval_=json.loads((ROOT/f'reports/track1_evaluation.{v}.json').read_text())
 assert review['passed'] and review['image_sha256']==digest(ROOT/f'reports/track1_spatial.{v}.jpg') and review['index_sha256']==digest(sp/f'{v}.parquet') and review['tensor_sha256']==digest(sp/f'{v}.pt')
 assert review['calibration_sha256']==digest(base/'track1_calibration_v1/model.json')
 counts=dict(spatial_observations=len(rows),spatial_valid=sum(r['spatial_valid'] for r in rows),excluded=len(bad),tracks=len({r['entity_track_id'] for r in rows}),functional_windows=len(windows),valid_functional_windows=sum(r['valid'] for r in windows),appearance_valid=int(app['valid'].sum()))
 totals.update(counts);per_video.append(dict(video_id=v,**counts,manual_median_dominant_iou=eval_['manual_median_dominant_iou'],manual_median_full_mask_iou=eval_['manual_median_full_mask_iou']))
 print('Final shard integrity, numerical contracts and review PASS',v,counts,flush=True)
cal=json.loads((ROOT/'derived/track1_calibration_v1/model.json').read_text());projection=json.loads((ROOT/'derived/track1_appearance_v1/projection.json').read_text());training=json.loads((ROOT/'derived/training_v1/manifest.json').read_text())
allowed={c['video_id'] for c in choices if c['visor_split']=='train' and c['video_id'] in cfg['engineering_splits']['train']}
assert set(cal['training_videos'])<=allowed and set(projection['training_videos'])<=allowed
splits=cfg['engineering_splits'];assert not(set(splits['train'])&set(splits['validation']) or set(splits['train'])&set(splits['test']) or set(splits['validation'])&set(splits['test']))
for split in splits:
 index=pq.read_table(ROOT/f'derived/training_v1/{split}_index.parquet').to_pylist()
 assert all(r['video_id'] in splits[split] and r['sequence_length']==16 and len(r['row_indices'])==16 for r in index)
 assert len(index)>0
parity=json.loads((ROOT/'reports/track1_mps_parity.json').read_text());repro=json.loads((ROOT/'reports/track1_reproducibility.json').read_text());tracks=json.loads((ROOT/'reports/track1_identity_audit.json').read_text())
assert parity['passed'] and repro['passed'] and tracks['passed']
for suffix,r in repro['files'].items():assert r['original']==digest(ROOT/f'derived/track1_spatial_v1/P04_109.{suffix}')
assert repro['functional_rebuild']['passed']
for suffix,r in repro['functional_rebuild']['files'].items():assert r['original']==digest(ROOT/f'derived/track1_functional_v1/P04_109.{suffix}')
coverage=cal['evaluations']['validation/manual_sparse']['after']['coverage95'];source_coverage=cal['evaluations']['source_visor_validation/manual_sparse']['after']['coverage95']
assert json.loads((ROOT/'reports/track1_decoder_parity.json').read_text())['passed']
gates=dict(GOLD_FUNCTIONAL_REPRODUCIBILITY=True,DECODER_RGB_PARITY=True,DATA_CANONICAL_V1=True,SPATIAL_V1=all(r['manual_median_dominant_iou']>.85 for r in per_video),UNCERTAINTY_SPATIAL_V1=.85<coverage<.995 and .85<source_coverage<.995,FUNCTIONAL_V1=True,COLLOCATION_V1=True,APPEARANCE_V1=True,IDENTITY_SOURCE_POLICY=True,SPLITS_V1=True,CPU_MPS_PARITY=True,GOLD_SPATIAL_REPRODUCIBILITY=True,VISUAL_REVIEW_V1=True)
assert all(gates.values()),gates
ready=dict(ready=True,scope='Track 1 evidence representation and valid functional sequences; no Track 2 neural dynamics training or forecasting validation',**identity(cfg),gates=gates)
atomic_json(ROOT/'derived/track1_status.json',ready)
with Track1Dataset() as dataset:
 cur=dataset.db.execute('SELECT video_id,entity_track_id,window_end_us FROM functional WHERE valid ORDER BY video_id,entity_track_id,window_end_us LIMIT 1');v,track,end=cur.fetchone()
 sample=dataset.get_state(v,track,end);nodes=dataset.get_collocation(v,track,end)
 assert sample['coefficients'].shape==(4,35) and sample['coefficient_cov'].shape==(35,4,4) and nodes['xi'].shape==(4,68)
 smoke=dict(passed=True,video_id=v,entity_track_id=track,window_end_us=end,coefficient_shape=[4,35],coefficient_covariance_shape=[35,4,4],collocation_state_shape=[4,68])
resources=[json.loads(line) for line in (ROOT/'reports/track1_resources.jsonl').read_text().splitlines()]
global_resources=[json.loads(line) for line in (ROOT/'reports/track1_global_resources.jsonl').read_text().splitlines()]
resource=dict(peak_controller_tree_rss_gib=max(r['rss_gib'] for r in resources),peak_global_project_python_rss_gib=max(r['project_python_rss_gib'] for r in global_resources),minimum_available_gib=min(r['available_gib'] for r in resources+global_resources),peak_mps_driver_per_process_gib=max(r.get('mps_driver_gib',0) for r in resources),oom_detected=False,aggregate_watch_log='reports/track1_global_resources.jsonl',note='CPU fitting used a memory-admitted video pool; appearance used up to three concurrent Metal/decoder pipelines. MPS memory is unified with system memory.')
report=dict(**ready,source_gate_scope='Accepted observations only; every canonical mask is accounted for in selected spatial rows or explicit exclusion records. Unresolved timestamps are never snapped.',totals=dict(totals),exclusions=dict(excluded),videos=per_video,sequence_counts=training['sequence_counts'],calibration=dict(spatial_covariance_multiplier=cal['kappa_cov'],temporal_covariance_multiplier=cal['temporal_covariance_multiplier'],validation_manual_coverage95=coverage,source_visor_validation_manual_coverage95=source_coverage,training_videos=cal['training_videos']),appearance_projection=dict(training_observations=projection['training_observations'],training_videos=projection['training_videos'],dimension=128,final_train_top128_variance_fraction=projection['progress'][-1]['top128_fraction']),numerical_shard_checks=numerical,contract_tests=15,reader_smoke=smoke,resources=resource,limitations=['Track identities are conservative source-linked hypotheses; no independent physical identity ground truth. Large-motion candidates are reported for later association audit.','A single dominant outer spline does not encode every component/hole; canonical source topology is retained and appearance subtracts holes.','95% calibration targets held-out contour representation error; 68% coverage is conservative and is reported separately.','Degree-three one-second compression smooths abrupt changes. Held-out temporal interpolation error exceeds nearest-observation error on this pilot; no future-dynamics advantage is claimed.','Unresolved timestamps and quarantined input geometry are excluded explicitly; self-intersecting fitted splines and insufficiently supported functions remain invalid.','Camera resize checks are sampled; bearings are nonmetric and metric 3D stays disabled.','Small/thin objects can have weak feature-grid cores; inspect appearance_valid and core_halo_mass.','Neural Track 2 training, Koopman dynamics and event-residual training remain outside this Track 1 implementation.'])
atomic_json(ROOT/'reports/track1_readiness.json',report)
packages=['torch','torchvision','PyWavelets','psutil','threadpoolctl','numpy','scipy','pyarrow','duckdb','opencv-python-headless','av','Pillow','PyYAML']
(ROOT/'configs/track1_requirements.lock.txt').write_text('\n'.join(p+'=='+md.version(p) for p in packages)+'\n')
print('TRACK 1 FINAL GATES PASSED',dict(totals),training['sequence_counts'],flush=True)
