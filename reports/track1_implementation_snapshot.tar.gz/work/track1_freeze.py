from pathlib import Path
import json,tarfile
from pipeline.common import ROOT,digest,atomic_json
from track1.artifacts import identity,load_config
cfg=load_config();r=json.loads((ROOT/'reports/track1_readiness.json').read_text());assert r['ready']
assert r['code_sha256']==identity(cfg)['code_sha256'];assert not list((ROOT/'derived').rglob('*.tmp'))
repro=json.loads((ROOT/'reports/track1_reproducibility.json').read_text());assert repro['passed'] and repro['functional_rebuild']['passed']
assert json.loads((ROOT/'reports/track1_decoder_parity.json').read_text())['passed']
assert '15 passed' in (ROOT/'work/track1_tests.log').read_text()
# Promote measured validation, not an untested completion claim, into the project docs.
p=ROOT/'TRACK1.md';text=p.read_text();marker='\n## Completed pilot results\n'
if marker in text:text=text.split(marker)[0]
text+=marker+f'''
The final Track 1 gates pass for all 11 pilot videos. The store contains {r['totals']['spatial_observations']:,} fitted spatial observations, {r['totals']['spatial_valid']:,} valid spatial fits, {r['totals']['tracks']:,} conservative source-linked segments, and {r['totals']['valid_functional_windows']:,} valid functional windows out of {r['totals']['functional_windows']:,} retained windows. It includes {r['totals']['appearance_valid']:,} usable appearance vectors.

The 16-state engineering sequence counts are {r['sequence_counts']['train']:,} train, {r['sequence_counts']['validation']:,} validation and {r['sequence_counts']['test']:,} test. These are overlapping sequences, not independent examples. Official split columns and source-compatibility flags remain essential.

The learned projection uses {r['appearance_projection']['training_observations']:,} source-compatible training observations; its first 128 components retain {100*r['appearance_projection']['final_train_top128_variance_fraction']:.1f}% of training feature variance. Held-out manual 95% contour coverage is {100*r['calibration']['validation_manual_coverage95']:.2f}% on engineering validation and {100*r['calibration']['source_visor_validation_manual_coverage95']:.2f}% on source VISOR validation. Per-video median dominant-component IoU ranges from approximately 0.946 to 0.964 in the sampled manual-mask evaluation.

All 15 tests pass. The gold spatial and functional rebuilds match tensors and file hashes exactly. Real-frame CNN features agree between CPU and Metal, and software/VideoToolbox RGB matches exactly in four sampled codec/timestamp checks. Sampled camera and spatial overlays were reviewed for every video. Reported process-tree RSS peaked at {r['resources']['peak_controller_tree_rss_gib']:.2f} GiB; available system memory stayed above {r['resources']['minimum_available_gib']:.2f} GiB. No OOM occurred.

The fixed degree-three temporal representation has higher held-out interpolation error than nearest-observation lookup on this pilot. It is a continuous compression with uncertainty and derivatives, and has no demonstrated forecasting advantage. The degree and robustness ablations are recorded without changing the prescribed baseline. Small or thin objects can also have weak feature-grid cores; inspect appearance validity and core/halo mass.

A tested reader example is:

```python
from track1.store import Track1Dataset

with Track1Dataset() as dataset:
    state = dataset.get_state(
        "{r['reader_smoke']['video_id']}",
        "{r['reader_smoke']['entity_track_id']}",
        {r['reader_smoke']['window_end_us']},
    )
    assert state["valid"]
    # coefficients: (4,35), coefficient_cov: (35,4,4), xi: (4,68)
```

See `reports/track1_readiness.json`, `reports/track1_diagnostics.png`, `reports/track1_ablations.json`, `reports/track1_covariance_ablation.json`, `reports/track1_identity_audit.json` and `reports/track1_freeze_manifest.json`. The implementation snapshot includes the exact source/configuration, experiment helpers and official frozen backbone weights. The raw dataset and canonical/v1 remain unchanged.

Primary implementation references: [SciPy B-splines](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.BSpline.html), [PyWavelets periodised DWT](https://pywavelets.readthedocs.io/en/stable/ref/dwt-discrete-wavelet-transform.html), and [TorchVision MobileNetV3-Small](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.mobilenet_v3_small.html).
'''
p.write_text(text)
p=ROOT/'README.md';text=p.read_text();marker='\nTrack 1 is now implemented'
if marker in text:text=text.split(marker)[0]
text+=f'''\nTrack 1 is now implemented and fitted end to end on the pilot. Its versioned outputs are in `derived/`, with {r['totals']['valid_functional_windows']:,} valid functional states and participant-separated sequence indices. See [TRACK1.md](TRACK1.md) for the implementation, commands, tested reader example, measured results and limitations. The canonical source store remains architecture-neutral and unchanged. `reports/track1_readiness.json` records the completed Track 1 gates.\n'''
p.write_text(text)
# Preserve all executable sources needed to regenerate this phase without a Git checkout.
paths=[ROOT/'README.md',ROOT/'TRACK1.md',ROOT/'pyproject.toml',ROOT/'work/track1_weights/mobilenet_v3_small-047dcff4.pth']
for folder in ['src/pipeline','src/track1','tests','configs']:
 paths += [p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += list((ROOT/'work').glob('track1_*.py'))
archive=ROOT/'reports/track1_implementation_snapshot.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
files=list(paths)+[p for p in (ROOT/'derived').rglob('*') if p.is_file()]
files += [p for p in (ROOT/'reports').glob('track1*') if p.suffix in ['.json','.jsonl','.jpg','.png'] and p.name!='track1_freeze_manifest.json']
files += [ROOT/'work/track1_tests.log',archive]
freeze=dict(**identity(cfg),ready=True,scope='Track 1 mathematical fits, uncertainty calibration, frozen appearance/PCA and functional sequence cache',source_raw_and_canonical_unchanged=True,files={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(set(files))})
atomic_json(ROOT/'reports/track1_freeze_manifest.json',freeze)
print('TRACK 1 IMPLEMENTATION AND ARTEFACT FREEZE COMPLETE',len(freeze['files']),'files',flush=True)
