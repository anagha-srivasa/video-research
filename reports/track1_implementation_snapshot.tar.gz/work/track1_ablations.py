from collections import defaultdict
import json,time
import numpy as np
import pyarrow.parquet as pq
import pywt
from track1.artifacts import ROOT,load_config,load_shard
from track1.spatial import fit_spline,align_seam
from track1.numerics import spline_basis,basis,weighted_solve,huber_weights,wavelet_matrix
from track1.temporal import fit_function
from pipeline.common import atomic_json
cfg=load_config();cal=json.loads((ROOT/'derived/track1_calibration_v1/model.json').read_text());results=defaultdict(list);temporal=defaultdict(list);phase=[];parity=[]

def temporal_reference(t,h,var,prov,quality,start,degree,loss='huber',solver='cholesky'):
 tau=2*(t-start)-1;phi=basis(tau,degree=degree);k=degree+1
 qt=np.diff(np.r_[t[0],(t[1:]+t[:-1])/2,t[-1]])
 base=qt[:,None]*prov[:,None]*quality[:,None]/(var+cfg['temporal']['variance_floor']);w=base.copy()
 prior=np.diag(cfg['temporal']['lambda_modes']*np.arange(k)**2+cfg['temporal']['lambda_ridge'])
 for iteration in range(cfg['temporal']['irls_iterations']):
  c=np.stack([weighted_solve(phi,h[:,d],w[:,d],prior,force_qr=solver=='qr')[0] for d in range(h.shape[1])],axis=1)
  r=(h-phi@c)/np.sqrt(var+cfg['temporal']['variance_floor'])
  robust=np.ones_like(r) if loss=='l2' else 1/(1+r*r) if loss=='cauchy' else huber_weights(r,cfg['temporal']['huber_delta'])
  w=base*robust
 return c

for v in cfg['engineering_splits']['train']+cfg['engineering_splits']['validation']+cfg['engineering_splits']['test']:
 rows=pq.read_table(ROOT/f'derived/track1_spatial_v1/{v}.parquet').to_pylist();state=load_shard(ROOT/f'derived/track1_spatial_v1/{v}.pt');split=rows[0]['engineering_split']
 manual=[r for r in rows if r['source_kind']=='manual_sparse' and r['spatial_valid']]
 for r in [manual[i] for i in np.linspace(0,len(manual)-1,min(24,len(manual)),dtype=int)]:
  y=state['boundary'][r['row_index']].astype(float);weights=np.ones(64);weights[::4]=0
  settings=[('controls_'+str(m),dict(cfg['spatial'],control_points=m),False) for m in [8,16,24]]
  settings += [('spline_degree_'+str(d),dict(cfg['spatial'],degree=d),False) for d in [2,3,4]]
  settings += [('spatial_l2',dict(cfg['spatial'],irls_iterations=1),False),('spatial_huber',cfg['spatial'],False),('spatial_qr',cfg['spatial'],True)]
  for name,options,qr in settings:
   fit=fit_spline(y,options,r['provenance_weight']*r['geometry_weight'],force_qr=qr,sample_weights=weights)
   error=fit['residual_normal'][::4];variance=fit['normal_var'][::4]*cal['kappa_cov']
   results[split+'/'+name].append(dict(rmse=float(np.sqrt(np.mean(error**2))),coverage95=float(np.mean(np.abs(error)<=1.9599639845*np.sqrt(variance))),self_intersection=fit['self_intersection']))
 tracks=defaultdict(list)
 for r in rows:
  if r['spatial_valid']:tracks[r['entity_track_id']].append(r)
 count=0
 for track,rs in sorted(tracks.items()):
  if count>=24:break
  if len(rs)<10:continue
  ts=np.array([r['timestamp_us'] for r in rs])/1e6
  if ts[-1]-ts[0]<.65:continue
  end=np.floor(ts[-1]*4)/4;local=np.flatnonzero((ts>=end-1)&(ts<=end))
  if len(local)<10:continue
  ids=np.array([rs[j]['row_index'] for j in local]);t=ts[local];h=state['h'][ids].astype(float);var=state['variance'][ids].astype(float)*cal['kappa_cov'];prov=np.array([rs[j]['provenance_weight'] for j in local]);quality=np.array([rs[j]['geometry_weight'] for j in local])
  hold=len(t)//2;keep=np.arange(len(t))!=hold
  options=[('degree_'+str(d),d,'huber','cholesky',True) for d in [2,3,4]]+[(loss,3,loss,'cholesky',True) for loss in ['l2','cauchy']]+[('qr',3,'huber','qr',True),('no_provenance',3,'huber','cholesky',False)]
  for name,degree,loss,solver,useprov in options:
   c=temporal_reference(t[keep],h[keep],var[keep],prov[keep] if useprov else np.ones(keep.sum()),quality[keep],end-1,degree,loss,solver)
   prediction=basis(2*(t[hold]-(end-1))-1,degree=degree)@c
   temporal[split+'/'+name].append(float(np.mean((prediction-h[hold])**2)))
   if name=='degree_3':
    ref=fit_function(t[keep],h[keep],var[keep],prov[keep],cfg['temporal'],end-1,quality[keep]);error=float(np.max(np.abs(ref.coefficients-c)));parity.append(error);assert error<1e-7
  # Compare canonical polynomial compression against nearest observed state (not future prediction).
  nearest=np.flatnonzero(keep)[np.argmin(np.abs(t[keep]-t[hold]))];temporal[split+'/nearest'].append(float(np.mean((h[nearest]-h[hold])**2)))
  count+=1
 for a,b in list(zip(rows,rows[1:]))[::20]:
  if a['entity_track_id']!=b['entity_track_id']:continue
  i,j=a['row_index'],b['row_index'];x=state['boundary'][i].astype(float);y=state['boundary'][j].astype(float)
  fixedx,_=align_seam(x,None);fixedy,_=align_seam(y,None)
  norm=lambda z:(z-z.mean(0))/max(np.linalg.norm(z-z.mean(0)),1e-12)
  phase.append(dict(aligned_mse=float(np.mean((norm(x)-norm(y))**2)),fixed_reference_mse=float(np.mean((norm(fixedx)-norm(fixedy))**2))))
 print('Ablations complete',v,flush=True)
summary={k:dict(n=len(v),heldout_normal_rmse_px=float(np.mean([r['rmse'] for r in v])),coverage95=float(np.mean([r['coverage95'] for r in v])),self_intersections=sum(r['self_intersection'] for r in v)) for k,v in results.items()}
tsummary={k:dict(n=len(v),heldout_state_rmse=float(np.sqrt(np.mean(v)))) for k,v in temporal.items()}
w=wavelet_matrix();rng=np.random.default_rng(41);control=rng.normal(size=(16,2));z=w@control
wavelet=dict(db2_inverse_max_error=float(np.max(np.abs(w.T@z-control))),db2_energy_error=float(abs(np.sum(z*z)-np.sum(control*control))),swt_shift_equivariance_max_error=float(np.max(np.abs(np.asarray(pywt.swt(np.roll(control,1,axis=0),'db2',level=1,axis=0))-np.roll(np.asarray(pywt.swt(control,'db2',level=1,axis=0)),1,axis=2)))))
report=dict(spatial=summary,temporal=tsummary,reference_solver_max_parity_error=max(parity),seam=dict(n=len(phase),aligned_median_mse=float(np.median([p['aligned_mse'] for p in phase])),fixed_reference_median_mse=float(np.median([p['fixed_reference_mse'] for p in phase]))),wavelet=wavelet,selection='Plan baseline remains M16/cubic/db2/Huber/degree3/Cholesky with QR fallback. Ablations are diagnostic; held-out results did not tune the frozen configuration.',limits='Temporal holdout tests interpolation/compression, not future prediction. Track 2 ablations are outside Track 1 scope; no claim of dynamics forecasting advantage.')
atomic_json(ROOT/'reports/track1_ablations.json',report)
print('ABLATION REPORT COMPLETE',flush=True)
