from pathlib import Path
import json
import numpy as np
from pipeline.common import ROOT,digest,atomic_json
from track1.artifacts import load_config,load_shard
from track1.offline import spatial_video
cfg=load_config();choice=next(c for c in json.loads((ROOT/'dataset/metadata/pilot_selection.json').read_text()) if c['video_id']=='P04_109')
copy=dict(cfg,output='work/track1_repro');spatial_video(copy,choice)
a=load_shard(ROOT/'derived/track1_spatial_v1/P04_109.pt');b=load_shard(ROOT/'work/track1_repro/track1_spatial_v1/P04_109.pt')
arrays={k:dict(shape=list(a[k].shape),exact_equal=bool(np.array_equal(a[k],b[k],equal_nan=True))) for k in a}
files={suffix:dict(original=digest(ROOT/f'derived/track1_spatial_v1/P04_109.{suffix}'),rebuilt=digest(ROOT/f'work/track1_repro/track1_spatial_v1/P04_109.{suffix}')) for suffix in ['pt','parquet','excluded.parquet','camera.json']}
passed=all(x['exact_equal'] for x in arrays.values()) and all(x['original']==x['rebuilt'] for x in files.values())
atomic_json(ROOT/'reports/track1_reproducibility.json',dict(passed=passed,video_id='P04_109',method='Independent complete spatial rebuild in a separate folder; exact tensor and file SHA256 comparisons',arrays=arrays,files=files))
assert passed
print('Independent gold spatial rebuild EXACTLY MATCHES all arrays and files',flush=True)
