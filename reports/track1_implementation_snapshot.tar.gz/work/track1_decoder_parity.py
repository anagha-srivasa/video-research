import av,json,numpy as np,duckdb
from av.codec.hwaccel import HWAccel
from pipeline.common import ROOT,atomic_json
results=[]
for v,t in [('P04_109',143780000),('P08_09',333833500),('P11_16',201701500),('P21_01',96863433)]:
 with duckdb.connect() as d:pts,t=d.execute('SELECT pts_raw,timestamp_us FROM read_parquet(?) ORDER BY abs(timestamp_us-?) LIMIT 1',[str(ROOT/f'canonical/v1/frames.{v}.parquet'),t]).fetchone()
 images=[]
 for hw in [None,HWAccel('videotoolbox',allow_software_fallback=False)]:
  with av.open(str(ROOT/f'dataset/videos/{v}.MP4'),hwaccel=hw) as c:
   s=c.streams.video[0];s.codec_context.thread_count=4;c.seek(pts,stream=s,backward=True)
   for frame in c.decode(s):
    if frame.pts==pts:images.append(frame.reformat(width=448,height=256,format='rgb24').to_ndarray());break
    if frame.pts>pts:raise ValueError('Indexed presentation timestamp skipped')
 assert len(images)==2
 error=np.abs(images[0].astype(float)-images[1].astype(float));r=dict(video_id=v,timestamp_us=t,mean_absolute_rgb_error=float(error.mean()),max_absolute_rgb_error=float(error.max()),passed=bool(error.mean()<1 and error.max()<12));results.append(r);print(r,flush=True)
assert all(r['passed'] for r in results)
atomic_json(ROOT/'reports/track1_decoder_parity.json',dict(passed=True,comparison='Software vs VideoToolbox decoded RGB, identical native PTS and PyAV 448x256 reformat',videos=results))
