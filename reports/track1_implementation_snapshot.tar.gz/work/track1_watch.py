from pathlib import Path
import psutil,time,json
ROOT=Path(__file__).resolve().parents[1];records=[];empty=0
while empty<3:
 jobs=[];processes=[]
 for p in psutil.process_iter(['pid','cmdline','name']):
  try:
   cmd=p.info['cmdline'] or []
   if cmd and 'python' in p.info['name'].lower() and Path(p.cwd())==ROOT:
    processes.append(p)
    if 'track1.run' in cmd or any('track1_appearance_worker.py' in x for x in cmd):jobs.append(p)
  except psutil.Error:pass
 empty=0 if jobs else empty+1
 rss=0
 for p in processes:
  try:rss+=p.memory_info().rss
  except psutil.Error:pass
 available=psutil.virtual_memory().available
 record=dict(time=time.strftime('%Y-%m-%dT%H:%M:%S%z'),project_python_rss_gib=rss/2**30,available_gib=available/2**30,cpu_percent=psutil.cpu_percent(),jobs=[p.pid for p in jobs])
 with (ROOT/'reports/track1_global_resources.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 records.append(record)
 if jobs and (rss>20*2**30 or available<5*2**30):
  sides=[p for p in jobs if any('track1_appearance_worker.py' in x for x in p.cmdline())]
  if sides:
   p=sides[-1]
   for child in p.children(recursive=True):child.terminate()
   p.terminate();print('Stopped supplementary worker at memory reserve; primary pipeline can rebuild that checkpoint',flush=True)
 time.sleep(5)
(ROOT/'reports/track1_global_resource_summary.json').write_text(json.dumps(dict(peak_project_python_rss_gib=max(r['project_python_rss_gib'] for r in records),minimum_available_gib=min(r['available_gib'] for r in records),peak_cpu_percent=max(r['cpu_percent'] for r in records),samples=len(records)),indent=2)+'\n')
