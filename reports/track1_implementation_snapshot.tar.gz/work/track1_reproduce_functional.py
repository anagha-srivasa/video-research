import json
from pathlib import Path
import numpy as np
from pipeline.common import ROOT,atomic_json,digest
from track1.artifacts import load_config,load_shard
from track1.offline import functional_video
cfg=load_config();choice=next(c for c in json.loads((ROOT/'dataset/metadata/pilot_selection.json').read_text()) if c['video_id']=='P04_109')
folder=ROOT/'work/track1_repro/track1_appearance_v1';folder.mkdir(exist_ok=True)
link=folder/'P04_109.pt'
if not link.exists():link.symlink_to(ROOT/'derived/track1_appearance_v1/P04_109.pt')
calibration_folder=ROOT/'work/track1_repro/track1_calibration_v1';calibration_folder.mkdir(exist_ok=True)
calibration_link=calibration_folder/'model.json'
if not calibration_link.exists():calibration_link.symlink_to(ROOT/'derived/track1_calibration_v1/model.json')
functional_video(dict(cfg,output='work/track1_repro'),choice)
a=load_shard(ROOT/'derived/track1_functional_v1/P04_109.pt');b=load_shard(ROOT/'work/track1_repro/track1_functional_v1/P04_109.pt')
arrays={k:bool(np.array_equal(a[k],b[k],equal_nan=True)) for k in a}
files={suffix:dict(original=digest(ROOT/f'derived/track1_functional_v1/P04_109.{suffix}'),rebuilt=digest(ROOT/f'work/track1_repro/track1_functional_v1/P04_109.{suffix}')) for suffix in ['pt','parquet']}
passed=all(arrays.values()) and all(r['original']==r['rebuilt'] for r in files.values())
p=ROOT/'reports/track1_reproducibility.json';r=json.loads(p.read_text());r['functional_rebuild']=dict(passed=passed,arrays=arrays,files=files,method='Independent full functional fit using independently rebuilt spatial gold and frozen original appearance/calibration inputs')
r['passed']=r['passed'] and passed;atomic_json(p,r);assert passed
print('Independent full gold functional fitting EXACTLY MATCHES all tensors and files',flush=True)
