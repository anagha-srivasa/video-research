import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[key]='1'
import sys,json,logging
from pathlib import Path
import torch
from track1.artifacts import ROOT,load_config,Monitor
from track1.appearance import backbone,extract_video
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
cfg=load_config();torch.set_num_threads(2);torch.mps.set_per_process_memory_fraction(.2)
choices=json.loads((ROOT/'dataset/metadata/pilot_selection.json').read_text());model=backbone().to('mps')
with Monitor(cfg) as monitor:
 for video in sys.argv[1:]:
  choice=next(c for c in choices if c['video_id']==video);extract_video(cfg,choice,model,torch.device('mps'),monitor)
print('Parallel appearance checkpoints complete',sys.argv[1:],flush=True)
