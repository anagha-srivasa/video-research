import json
import numpy as np
import pyarrow.parquet as pq
from track1.artifacts import ROOT,load_config,load_shard
from track1.spatial import fit_spline
from track1.numerics import spline_basis
from track1.calibration import coverage_metrics
from pipeline.common import atomic_json
cfg=load_config();cases=[];phi=spline_basis()
for p in sorted((ROOT/'derived/track1_spatial_v1').glob('P*.parquet')):
 if '.excluded.' in p.name:continue
 rows=pq.read_table(p).to_pylist();s=load_shard(p.with_suffix('.pt'));manual=[r for r in rows if r['spatial_valid'] and r['source_kind']=='manual_sparse']
 for r in [manual[i] for i in np.linspace(0,len(manual)-1,min(len(manual),24),dtype=int)]:
  y=s['boundary'][r['row_index']].astype(float);w=np.ones(64);w[::4]=0;fit=fit_spline(y,cfg['spatial'],sample_weights=w)
  diag=np.sum(phi**2*np.diag(fit['covariance'])[None],axis=1)
  for i in range(0,64,4):cases.append(dict(video_id=r['video_id'],engineering_split=r['engineering_split'],visor_split=r['visor_split'],error=float(fit['residual_normal'][i]),none=cfg['spatial']['sigma_floor_pixels']**2,diagonal=float(diag[i]),block=float(fit['normal_var'][i])))
report={}
train=[r for r in cases if r['engineering_split']=='train' and r['visor_split']=='train']
for mode in ['none','diagonal','block']:
 kappa=float(np.quantile([r['error']**2/max(r[mode],1e-20) for r in train],.95)/1.9599639845**2);metrics={}
 for split in ['train','validation','test','source_visor_validation']:
  selected=[r for r in cases if (r['visor_split']=='val' if split=='source_visor_validation' else r['engineering_split']==split)]
  metrics[split]=coverage_metrics([r['error'] for r in selected],[r[mode]*kappa for r in selected])
 report[mode]=dict(train_only_calibration_multiplier=kappa,evaluations=metrics)
atomic_json(ROOT/'reports/track1_covariance_ablation.json',dict(models=report,training_videos=sorted({r['video_id'] for r in train}),cases=len(cases),interpretation='none uses one global fixed noise; diagonal drops coefficient correlations; block uses full control covariance for each independent x/y coordinate. All multipliers fitted on source-compatible engineering-train manual masks only.'))
print('Covariance ablation complete',len(cases),flush=True)
