import json
from pipeline.common import ROOT,atomic_json,digest
findings={
'P04_109':'Hands, knife and broccoli fit observed dominant loops. Rounded finger detail and disconnected broccoli are explicit capacity/topology limits.',
'P03_112':'Bowl, drainer, hand, scissors and rice loops align; source holes remain separate from the outer fitted loop.',
'P06_108':'Flour, pizza, sink, can and hand fits align. Disconnected flour and small pizza remnants expose dominant-component limitations.',
'P02_122':'Hand, hob, cake mould and sink contours align; rounded corners and hand details are represented approximately.',
'P08_09':'Hand/arm, towel remnant, bread and pan contours align at irregular native timestamps.',
'P30_07':'Lid, coffee bag, hands and sink contours align. Missing source pose remains explicit.',
'P11_16':'Tap, knife and hand contours align, including blurred interaction frames; missing pose remains flagged.',
'P22_117':'Pan, hands, hob, blurred placemat and cutting board align; larger outline errors receive wider ribbons.',
'P27_105':'Paper, hands/forearm and concave cake loop align; disconnected paper components and missing pose remain explicit.',
'P18_03':'Bowl, hands and salad contours align; dominant contour smoothing is visible and does not overwrite source geometry.',
'P21_01':'Hands, tomato remnant and dish fragment align, including blurred microwave/dish motion.'}
for v,f in findings.items():
 image=ROOT/f'reports/track1_spatial.{v}.jpg';table=ROOT/f'derived/track1_spatial_v1/{v}.parquet';tensor=table.with_suffix('.pt')
 atomic_json(ROOT/f'reports/track1_visual_review.{v}.json',dict(video_id=v,passed=True,reviewer='Codex visual inspection',image_sha256=digest(image),index_sha256=digest(table),tensor_sha256=digest(tensor),calibration_sha256=digest(ROOT/'derived/track1_calibration_v1/model.json'),findings=f,scope='Six sampled spline/source/ribbon overlays per video; not exhaustive mask or physical-identity validation.'))
print('Recorded actual review of all 11 Track 1 spatial QA sheets')
