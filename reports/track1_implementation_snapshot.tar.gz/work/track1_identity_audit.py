import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import pyarrow.parquet as pq
from track1.artifacts import load_shard
from pipeline.common import ROOT,atomic_json,digest
reports=[]
for p in sorted((ROOT/'derived/track1_spatial_v1').glob('P*.parquet')):
 if '.excluded.' in p.name:continue
 v=p.stem;rows=pq.read_table(p).to_pylist();s=load_shard(p.with_suffix('.pt'));tracks=defaultdict(list)
 for r in rows:tracks[r['entity_track_id']].append(r)
 duplicate=0;name_conflicts=0;subsequence_conflicts=0;links=0;motions=[];worst=[]
 for track,rs in tracks.items():
  duplicate+=len(rs)-len({r['timestamp_us'] for r in rs});name_conflicts+=len({r['entity_name'] for r in rs})>1
  subsequence_conflicts+=len({r['subsequence'] for r in rs if r['subsequence'] is not None})>1
  links+=len({r['interpolation_id'] for r in rs if r['interpolation_id'] is not None})>1
  for a,b in zip(rs,rs[1:]):
   i,j=a['row_index'],b['row_index'];dt=(b['timestamp_us']-a['timestamp_us'])/1e6
   radius=max(float((s['scale_native'][i]+s['scale_native'][j])/2),1)
   movement=float(np.linalg.norm(s['centre_native'][j]-s['centre_native'][i])/radius);motions.append(movement)
   if movement>3 and dt<=.35:worst.append(dict(entity_track_id=track,mask_a=a['mask_uid'],mask_b=b['mask_uid'],dt_seconds=dt,centroid_motion_radii=movement))
 report=dict(video_id=v,tracks=len(tracks),multi_observation_tracks=sum(len(rs)>1 for rs in tracks.values()),shared_endpoint_joined_tracks=links,duplicate_track_timestamps=duplicate,name_conflicts=name_conflicts,subsequence_conflicts=subsequence_conflicts,motion_radii_quantiles=np.quantile(motions,[.5,.95,.99,1]).tolist() if motions else [],large_motion_candidates=len(worst),large_motion_examples=sorted(worst,key=lambda x:-x['centroid_motion_radii'])[:10],index_sha256=digest(p),passed=duplicate==name_conflicts==subsequence_conflicts==0)
 reports.append(report);print(v,len(tracks),'large motion',len(worst),'q99',report['motion_radii_quantiles'][2],flush=True)
atomic_json(ROOT/'reports/track1_identity_audit.json',dict(passed=all(r['passed'] for r in reports),videos=reports,scope='Empirical name/subsequence/duplicate and motion audit of conservative source-linked segments; no independently annotated physical identity ground truth.',motion_warning='Three apparent radii per observed step is a diagnostic candidate, not a calibrated identity error.'))
